# Indium

A real, working pre-alpha of Indium, written in Rust. Source files use `.in` and
the executable is `indium`. This release executes programs with a tree-walking
interpreter. It does not yet compile Indium source to native machine code.

```indium
mode = terminal

fn greet(who: text) {
    print("Hello, " + who + "!")
}

greet("Indium")
```

## Documentation

Start with the [Indium handbook](docs/README.md) for a complete guide to the
implemented language. The release ZIP also includes **docs/guide.html**, a
self-contained offline copy you can open in your browser.

- [Getting started](docs/getting-started.md): installation, folders, first program.
- [Language](docs/language.md): syntax, types, collections, functions, modules.
- [Standard library](docs/standard-library.md): every current function and property.
- [Graphics and audio](docs/graphics-and-audio.md), [scheduling](docs/scheduling.md),
  [CLI](docs/cli.md), [recipes](docs/recipes.md), and [troubleshooting](docs/troubleshooting.md).

## What works

- Lexer, parser, lexical scopes, variables with inferred or annotated types.
- Signed 64-bit integers, finite decimals, text, booleans, `none`.
- Arithmetic, comparisons, short-circuit logic, useful type and result-state checks.
- Functions, closures, recursion, typed parameters and return values.
- Conditions, `while`, `for`, ranges, `loop`, `break`, `continue`, `return`.
- Mutable lists and maps, Unicode text, first-class functions.
- Built-in modules and cached, relative `.in` imports with cycle diagnostics.
- Terminal and background execution; OpenGL-backed 2D windows and input.
- Rectangles, lines, circles, PNG/JPEG/BMP images, and Unicode text rendering.
- Borderless/exclusive fullscreen controls, FPS limits, VSync configuration.
- Built-in OGG/Vorbis and PCM WAV audio, multiple voices, pause/resume/stop/volume.
- Independent simulation ticks, rendering frames, and recurring timers.
- Files, math, text helpers, and blocking HTTP through the installed `curl` program.
- `run`, `check`, `tokens`, `--help`, and `--version` commands.

Graphics and audio need no Indium imports or packages. `import game` enables the
game namespace. All these features belong to the same language and runtime.

## Build and run

On Windows, after building once, double-click **install-windows.cmd** to install
Indium for your account and add it permanently to PATH. Reopen your terminal,
then use `indium run program.in`. The standalone **Install-Indium.cmd** does the
same for an existing Windows build. See [Windows installation](docs/windows-installation.md).

This snapshot includes a tested Ubuntu 24.04 x86-64 binary. On a compatible Linux
system, use `./indium-linux run examples/hello.in` without building Rust first.
See [prebuilt/README.md](prebuilt/README.md). Other platforms use the source build
instructions below.

Use a current stable Rust toolchain (Cargo included) and the SDL2 development
library. Image decoding, fonts, and OGG/WAV decoding are Rust dependencies; this
project does **not** require SDL2_image, SDL2_ttf, or SDL2_mixer.

On Ubuntu/Debian:

```sh
sudo apt-get install build-essential libsdl2-dev
cargo build --release --locked
./target/release/indium run examples/hello.in
./target/release/indium run examples/2d.in
```

On macOS, install SDL2 with `brew install sdl2`, then build using Cargo.

On Windows with Rust's MSVC toolchain and Visual Studio C++ Build Tools installed:

1. Download the **Visual C++ development package** for SDL2 from
   <https://github.com/libsdl-org/SDL/releases> (choose an SDL2 release).
2. Extract it, then run the provided helper with the extracted SDL2 directory:

```powershell
.\scripts\build-windows.ps1 -Sdl2Root C:\path\to\SDL2
.\target\release\indium.exe run examples\hello.in
.\target\release\indium.exe run examples\2d.in
```

The helper finds `SDL2.lib` and copies `SDL2.dll` beside the executable. It uses
encoded compiler arguments so SDL2 paths containing spaces are passed correctly.
Use the x64 Rust toolchain and x64 SDL2 libraries. The user has successfully built
and run the terminal example on Windows. Windows graphics/audio and macOS builds
have not been tested on physical desktop systems here.

A terminal-only build needs no SDL2 development library:

```sh
cargo build --release --locked --no-default-features
./target/release/indium run examples/hello.in
```

For a Linux/macOS installed CLI, use `cargo install --path . --locked` after
setting up SDL2. On Windows, use the installer above so `SDL2.dll` is copied too.
All asset and file paths inside a program are relative to its `.in` source file,
including inside an imported module.

## CLI

```text
indium run examples/hello.in
indium run examples/2d.in --frames 120
indium run examples/hello.in --max-steps 100000
indium run my-program.in -- first-argument second-argument
indium check examples/imports.in
indium tokens examples/hello.in
indium --version
indium --help
```

`check` parses and checks the entire local module graph without executing it.
It checks names, known types, declared signatures, scopes, and control flow.
Dynamic calls and values obtained from module fields or collections are checked
at runtime. It is not a proof that a program will run without errors.

`build` and `install` currently exit with an explicit “not implemented” error.
They do not silently produce a launcher or pretend to install packages.

## Try the media demo

```indium
mode = 2d
import game

window.title = "Indium"
window.fps = 144
window.vsync = false
game.tps = 240
x = 0.0

every tick {
    x += 100 * game.dt
    if x > window.width { x = 0.0 }
} loop

every frame {
    renderer.clear("#11121b")
    renderer.circle(x, 200, 24, "indium")
    renderer.text("Hello from OpenGL", 24, 24)
    if input.key_pressed("escape") { stop() }
} loop
```

The larger `examples/2d.in` demo also includes OGG sound on Space, fullscreen on
F11, and arrow-key speed controls. `examples/audio.in` exercises both audio
formats. The included sound and checkerboard assets are original test fixtures,
not a final logo or borrowed music.

## Tests

```sh
cargo test --locked
cargo fmt --check
cargo clippy --all-targets -- -D warnings
```

The OpenGL integration test is opt-in because it needs a usable display:

```sh
cargo test --lib -- --ignored --test-threads=1
```

For headless Mesa systems, it can also be run with:

```sh
SDL_VIDEODRIVER=offscreen LIBGL_ALWAYS_SOFTWARE=1 \
  cargo test --lib -- --ignored --test-threads=1
SDL_AUDIODRIVER=dummy ./target/debug/indium run examples/audio.in
```

See [docs/validation.md](docs/validation.md) for the checks actually performed,
[docs/language.md](docs/language.md) for syntax and semantics, and
[docs/standard-library.md](docs/standard-library.md) for the implemented APIs.

## Current limits

This is a working foundation, not a completed Alpha 1.0 release. There is no
native compiler, 3D runtime, package registry, AI module, Discord module, or
Vulkan backend. Background mode uses the same process as terminal mode; it does
not detach or hide an inherited Windows console. Long audio tracks are decoded
in memory rather than streamed. Input, graphics, and timing still need testing
on physical Windows/macOS machines and audio devices.

The implementation uses runtime type checks alongside a conservative semantic
pass, not a complete static type system. It has explicit recursion/depth limits,
and no tracing garbage collector. See the language guide for details.

No open-source license has been selected. The creator retains rights to this
project's original source code. Third-party software and the bundled DejaVu font
retain their respective licenses; see [THIRD_PARTY.md](THIRD_PARTY.md).
